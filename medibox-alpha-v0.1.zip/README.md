# MediBox Alpha 0.1

Išmani šeimos vaistinėlė – veikiantis Flutter Alpha prototipas pagal patvirtintą MediBox vizualizaciją.

## Alpha ekranai
- Pagrindinis ekranas ir dienos dozės
- Vaistinėlė ir vaistų kategorijos
- Vaisto kortelė: veiklioji medžiaga, paskirtis, įspėjimai, atsargos, galiojimas
- Vaisto skenavimo / atpažinimo demonstracinis srautas
- „Man bloga“ simptomų vedlys
- Pilvo simptomų klausimynas ir saugumo vartai
- Turimų preparatų rodymas pagal simptomų kategoriją
- Šeimos nariai
- Priminimai

## Svarbu
Ši Alpha versija nėra medicinos priemonė ir nediagnozuoja. Vaistų informacija demonstracinė. Produkcinėje versijoje informacija turi būti siejama su oficialiais VVKT/EMA šaltiniais, o rekomendavimo logika turi turėti atskirą medicininės saugos validaciją.

## Android APK per GitHub Actions
Workflow `.github/workflows/android.yml` automatiškai sukuria Android platformos failus ir debug APK. GitHub → Actions → Build Android APK → paskutinio run'o Artifacts → `MediBox-Alpha-APK`.
