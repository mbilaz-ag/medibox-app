import 'package:flutter/material.dart';

void main() => runApp(const MediBoxApp());

const green = Color(0xFF079B7A);
const mint = Color(0xFFE9F8F4);
const navy = Color(0xFF102A43);

class Medicine {
  final String name, substance, purpose, expiry;
  final int stock;
  const Medicine(this.name, this.substance, this.purpose, this.expiry, this.stock);
}

const medicines = [
  Medicine('Euthyrox 50 µg', 'levotiroksinas', 'Skydliaukės hormonų pakaitinė terapija', '2028-01', 73),
  Medicine('Ibumetin 400 mg', 'ibuprofenas', 'Skausmui ir karščiavimui mažinti', '2028-04', 6),
  Medicine('Loratadine 10 mg', 'loratadinas', 'Alergijos simptomams lengvinti', '2027-09', 12),
  Medicine('Espumisan 40 mg', 'simetikonas', 'Pilvo pūtimui ir dujų kaupimuisi', '2027-11', 14),
];

class MediBoxApp extends StatelessWidget {
  const MediBoxApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'MediBox',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: const Color(0xFFF7FAF9),
      useMaterial3: true,
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, foregroundColor: navy),
    ),
    home: const Shell(),
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int i = 0;
  final pages = const [HomePage(), CabinetPage(), SymptomsPage(), FamilyPage(), RemindersPage()];
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: pages[i]),
    bottomNavigationBar: NavigationBar(
      selectedIndex: i, onDestinationSelected: (v)=>setState(()=>i=v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label:'Pagrindinis'),
        NavigationDestination(icon: Icon(Icons.medication_outlined), label:'Vaistinėlė'),
        NavigationDestination(icon: Icon(Icons.health_and_safety_outlined), label:'Man bloga'),
        NavigationDestination(icon: Icon(Icons.people_outline), label:'Šeima'),
        NavigationDestination(icon: Icon(Icons.notifications_outlined), label:'Priminimai'),
      ],
    ),
  );
}

class Brand extends StatelessWidget {
  const Brand({super.key});
  @override Widget build(BuildContext context) => const Row(children:[
    CircleAvatar(backgroundColor: green, child: Icon(Icons.add, color:Colors.white, size:30)),
    SizedBox(width:10), Text('MediBox', style:TextStyle(fontSize:30,fontWeight:FontWeight.w800,color:navy))
  ]);
}
Widget card(Widget child) => Card(elevation:0, color:Colors.white, shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)), child:Padding(padding:const EdgeInsets.all(16),child:child));

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context) => ListView(padding:const EdgeInsets.all(18),children:[
    const Brand(), const SizedBox(height:24),
    const Text('Labas! 👋',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold,color:navy)),
    const Text('Šiandienos vaistai ir tavo vaistinėlės būklė.',style:TextStyle(color:Colors.black54)),
    const SizedBox(height:16),
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text('Šiandien',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Chip(label:Text('1 / 3 išgerta'))]),
      const Divider(), dose('07:00','Euthyrox 50 µg',true), dose('14:00','Loratadine 10 mg',false), dose('21:00','Magnis',false)
    ])),
    const SizedBox(height:12),
    Row(children:[
      Expanded(child:FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ScanPage())),icon:const Icon(Icons.camera_alt),label:const Padding(padding:EdgeInsets.symmetric(vertical:16),child:Text('Nuskenuoti vaistą')))),
      const SizedBox(width:10),
      Expanded(child:FilledButton.tonalIcon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SymptomsPage())),icon:const Icon(Icons.health_and_safety),label:const Padding(padding:EdgeInsets.symmetric(vertical:16),child:Text('Man bloga')))),
    ]),
    const SizedBox(height:12),
    card(const Column(children:[
      ListTile(contentPadding:EdgeInsets.zero,leading:Icon(Icons.warning_amber_rounded,color:Colors.orange),title:Text('Ibumetin liko ~6 tabletės'),trailing:Icon(Icons.chevron_right)),
      Divider(), ListTile(contentPadding:EdgeInsets.zero,leading:Icon(Icons.event_busy,color:Colors.red),title:Text('2 preparatai baigs galioti per 30 dienų'),trailing:Icon(Icons.chevron_right))
    ])),
  ]);
  static Widget dose(String t,String n,bool done)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(radius:16,backgroundColor:done?mint:Colors.grey.shade100,child:Icon(done?Icons.check:Icons.schedule,size:18,color:done?green:Colors.grey)),title:Text(n),subtitle:Text(t),trailing:done?const Text('Išgerta',style:TextStyle(color:green,fontWeight:FontWeight.bold)):const Text('Laukia'));
}

class CabinetPage extends StatelessWidget {
  const CabinetPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Mano vaistinėlė',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold,color:navy)),
    const SizedBox(height:10), const SearchBar(hintText:'Ieškoti vaistų arba simptomo...',leading:Icon(Icons.search)),
    const SizedBox(height:14),
    Wrap(spacing:8,children:const [Chip(label:Text('Pagal vaistus')),Chip(label:Text('Skausmas')),Chip(label:Text('Alergija')),Chip(label:Text('Virškinimas'))]),
    const SizedBox(height:8),
    ...medicines.map((m)=>Card(elevation:0,child:ListTile(
      leading:const CircleAvatar(backgroundColor:mint,child:Icon(Icons.medication,color:green)),
      title:Text(m.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${m.substance}\nLikutis: ${m.stock} • Galioja ${m.expiry}'),
      isThreeLine:true,trailing:const Icon(Icons.chevron_right),
      onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MedicinePage(m:m))),
    )))
  ]);
}

class MedicinePage extends StatelessWidget {
  final Medicine m; const MedicinePage({super.key,required this.m});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(m.name)),body:ListView(padding:const EdgeInsets.all(18),children:[
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Apžvalga',style:TextStyle(color:green,fontWeight:FontWeight.bold)),
      const SizedBox(height:12), Text(m.name,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
      Text('Veiklioji medžiaga: ${m.substance}'),const Divider(),
      const Text('Kam vartojamas?',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:6),Text(m.purpose),
    ])),
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Svarbu žinoti',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('• Visada vadovaukitės konkretaus preparato pakuotės lapeliu.\n• Patikrinkite kontraindikacijas, sąveikas ir amžiaus ribas.\n• MediBox nekeičia gydytojo paskirto gydymo.')
    ])),
    card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Mano atsargos',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      Text('Turite: ${m.stock} vnt.'),Text('Galioja iki: ${m.expiry}'),const SizedBox(height:8),LinearProgressIndicator(value:(m.stock/100).clamp(0,1))
    ])),
    FilledButton.tonal(onPressed:(){},child:const Text('Oficialus pakuotės lapelis (VVKT)')),
  ]));
}

class ScanPage extends StatelessWidget {
  const ScanPage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Vaisto skenavimas')),body:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
    Expanded(child:Container(decoration:BoxDecoration(color:Colors.black87,borderRadius:BorderRadius.circular(24)),child:const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
      Icon(Icons.center_focus_strong,color:Colors.white,size:110),SizedBox(height:20),Text('Laikykite vaisto dėžutę kadre',style:TextStyle(color:Colors.white,fontSize:18))
    ])))),
    const SizedBox(height:14),
    const Text('Alpha demonstracija: kameros/OCR modulis bus prijungtas kitame techniniame etape.',textAlign:TextAlign.center),
    const SizedBox(height:12),
    FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RecognitionPage())),icon:const Icon(Icons.document_scanner),label:const Text('Demonstruoti atpažinimą'))
  ])));
}
class RecognitionPage extends StatelessWidget {
  const RecognitionPage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Atpažinome vaistą')),body:ListView(padding:const EdgeInsets.all(18),children:[
    card(const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(Icons.verified,color:green,size:44),SizedBox(height:8),Text('Ibumetin 400 mg tabletės',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
      Text('Ibuprofenas • N20'),Divider(),ListTile(contentPadding:EdgeInsets.zero,leading:Icon(Icons.check_circle,color:green),title:Text('Rastas vaistų registre')),
      Text('Kiekis pakuotėje: 20 tablečių'),Text('Galiojimo data: 2028-04')
    ])),
    FilledButton(onPressed:()=>Navigator.popUntil(context,(r)=>r.isFirst),child:const Text('Pridėti į vaistinėlę'))
  ]));
}

class SymptomsPage extends StatelessWidget {
  const SymptomsPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Man bloga',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold,color:navy)),
    const Text('Pasirink, kas labiausiai vargina. Tai nėra diagnozė.'),
    const SizedBox(height:16),
    symptom(context,Icons.sick,'Skauda'),symptom(context,Icons.thermostat,'Karščiuoju'),symptom(context,Icons.air,'Peršalau'),
    symptom(context,Icons.monitor_heart,'Pilvo problemos',abdominal:true),symptom(context,Icons.bubble_chart,'Alergija'),
    symptom(context,Icons.water_drop,'Viduriavimas / užkietėjimas'),symptom(context,Icons.healing,'Odos problemos'),
  ]);
  Widget symptom(BuildContext c,IconData i,String s,{bool abdominal=false})=>Card(elevation:0,child:ListTile(leading:Icon(i,color:green),title:Text(s,style:const TextStyle(fontWeight:FontWeight.w600)),trailing:const Icon(Icons.chevron_right),onTap:abdominal?()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const AbdominalPage())):null));
}

class AbdominalPage extends StatefulWidget {
  const AbdominalPage({super.key});
  @override State<AbdominalPage> createState()=>_AbdominalPageState();
}
class _AbdominalPageState extends State<AbdominalPage>{
  String place='Sunku pasakyti', type='Maudžia'; bool fever=false,vomit=false,blood=false;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Pilvo problemos')),body:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Kur jaučiate skausmą?',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    ...['Viršutinėje pilvo dalyje','Dešinėje','Kairėje','Apatinėje dalyje','Visą pilvą','Sunku pasakyti'].map((x)=>RadioListTile(value:x,groupValue:place,onChanged:(v)=>setState(()=>place=v!),title:Text(x))),
    const Divider(),const Text('Koks skausmas?',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    ...['Spazmai','Degina','Maudžia','Aštrus / labai stiprus'].map((x)=>RadioListTile(value:x,groupValue:type,onChanged:(v)=>setState(()=>type=v!),title:Text(x))),
    SwitchListTile(value:fever,onChanged:(v)=>setState(()=>fever=v),title:const Text('Ar yra temperatūra?')),
    SwitchListTile(value:vomit,onChanged:(v)=>setState(()=>vomit=v),title:const Text('Ar nuolat vemiate?')),
    SwitchListTile(value:blood,onChanged:(v)=>setState(()=>blood=v),title:const Text('Ar yra kraujo?')),
    FilledButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SafetyPage(danger:fever||vomit||blood||type=='Aštrus / labai stiprus'))),child:const Padding(padding:EdgeInsets.all(14),child:Text('Saugumo patikra')))
  ]));
}

class SafetyPage extends StatelessWidget {
  final bool danger; const SafetyPage({super.key,required this.danger});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Saugumo patikra')),body:Padding(padding:const EdgeInsets.all(18),child:danger?
    card(const Column(mainAxisSize:MainAxisSize.min,children:[
      Icon(Icons.warning_rounded,color:Colors.red,size:72),SizedBox(height:12),Text('Galimi pavojingi požymiai',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold,color:Colors.red)),
      SizedBox(height:10),Text('MediBox šioje situacijoje vaisto nerekomenduoja. Kreipkitės į gydytoją; jei būklė sunki ar greitai blogėja – skubios pagalbos.',textAlign:TextAlign.center)
    ])):
    ListView(children:[
      card(const Column(children:[Icon(Icons.check_circle,color:green,size:72),Text('Nerasta pasirinktų pavojingų požymių',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold),textAlign:TextAlign.center),SizedBox(height:8),Text('Pagal pateiktus atsakymus galima peržiūrėti jūsų vaistinėlėje esančius preparatus pagal jų paskirtį.',textAlign:TextAlign.center)])),
      const SizedBox(height:12),const Text('Jūsų vaistinėlėje radome',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      Card(child:ListTile(leading:const Icon(Icons.medication,color:green),title:const Text('Espumisan 40 mg'),subtitle:const Text('Simetikonas • pilvo pūtimui / dujų kaupimuisi\nTurite: ~14 kaps.'),isThreeLine:true,trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const MedicinePage(m:medicines[3]))))),
      const Padding(padding:EdgeInsets.only(top:12),child:Text('Svarbu: tai informacinis atitikimas pagal simptomų kategoriją ir preparato paskirtį, o ne diagnozė ar individualus gydymo paskyrimas.',style:TextStyle(color:Colors.black54)))
    ])
  ));
}

class FamilyPage extends StatelessWidget {
  const FamilyPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Mano šeima',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold,color:navy)),
    ...[('Aš','4 vaistai'),('Vaikas','2 vaistai'),('Mama','6 vaistai')].map((x)=>Card(child:ListTile(leading:const CircleAvatar(backgroundColor:mint,child:Icon(Icons.person,color:green)),title:Text(x.$1),subtitle:Text(x.$2),trailing:const Icon(Icons.chevron_right)))),
    FilledButton.tonalIcon(onPressed:(){},icon:const Icon(Icons.person_add),label:const Text('Pridėti šeimos narį'))
  ]);
}
class RemindersPage extends StatelessWidget {
  const RemindersPage({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Priminimai',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold,color:navy)),
    card(Column(children:[HomePage.dose('07:00','Euthyrox 50 µg',true),HomePage.dose('14:00','Loratadine 10 mg',false),HomePage.dose('21:00','Magnis',false)])),
    FilledButton.icon(onPressed:(){},icon:const Icon(Icons.add_alarm),label:const Text('Pridėti priminimą')),
    const SizedBox(height:16),card(const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Praleista dozė?',style:TextStyle(fontWeight:FontWeight.bold)),SizedBox(height:8),Text('Programėlė leis pažymėti „Išgėriau“, „Praleidau“ arba „Priminti vėliau“ ir saugos vartojimo istoriją.')]))
  ]);
}
